<?php

    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "fx_octrade_db";

    $connection = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>
